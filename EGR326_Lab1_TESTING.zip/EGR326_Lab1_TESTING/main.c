#include "msp.h"
void Port3_Initial();
void Port4_Initial();
void Port5_Initial();
uint8_t DebounceSwitch1();
uint8_t DebounceSwitch2();
void PORT4_IRQHandler();
uint8_t SW1;
uint8_t SW2;
uint8_t IRQ;

uint8_t RED_ON_S1 = 0;
uint8_t GREEN_ON_S1 = 0;
uint8_t BLUE_ON_S1 = 0;
uint8_t RED_ON_S2 = 0;
uint8_t GREEN_ON_S2 = 0;
uint8_t BLUE_ON_S2 = 0;

enum Counter{
    RED,
    GREEN,
    BLUE,
    REDRED,
    REDGREEN,
    REDBLUE,
    GREENRED,
    GREENGREEN,
    GREENBLUE,
    BLUERED,
    BLUEGREEN,
    BLUEBLUE
};

uint8_t PressedIRQ;
uint8_t PressedMain;
uint8_t PressedInc;

void main(void)
{
    Port4_Initial();                                            //initializing of port 4
    Port5_Initial();                                            //initializing of port 5
    Port3_Initial();                                            //initializing of port 3(port 6)
    P5OUT &= ~0x07;
    NVIC->ISER[1] = 1 << ((PORT4_IRQn) & 31);
    __enable_irq();                                             //irq enable
    int Done = 0;
    int DoneSW2 = 0;
    int i = 0;
    int RESTART = 1;
    int checkSW1 = 0;
WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD; // stop watchdog timer

enum Counter counter;                                           //enum for state
counter = RED;                                                  //initializing state

while(1){
   hereLEDSOFF:                                                 //beginning of all leds off state
   for(i = 0; i <= 100; i++){                                   //ensures switch button 1 has been released
       DebounceSwitch1();
       if(SW1 == 0){
           RESTART = 1;
       }
   }
   DebounceSwitch1();                                           //ensures switch button 1 has been pressed
   if(SW1 == 1 && RESTART == 1){
       RESTART = 0;
       switch(counter){

       //---------------RED CASES--------------------//
       case RED:
           hereRED:
           if(BLUE_ON_S2 == 0){                     //checks to see if blue is on from switch 2
               P5OUT &= ~0x04;                     //sets P5.2 to 0
               BLUE_ON_S1 = 0;
           }
           if(RED_ON_S1 == 0){                      //checks to see if red is on from switch 1
               Done = 0;
               P5OUT |= 0x01;                      //sets P5.0 to 1
               RED_ON_S1 = 1;
           }
           for(i = 0; i <= 100; i++){               //ensures button has been released for IRQ
               DebounceSwitch2();
               if(SW2 == 0){
                   DoneSW2 = 1;
               }
           }
           DebounceSwitch2();                       //checks for new button press for switch 2 to enable IRQ
           if(SW2 == 1 && DoneSW2 == 1 && IRQ == 0){
               DoneSW2 = 0;
               __enable_irq();
           }
           if(IRQ == 1){                            //IRQ states for second switch button colors
               __disable_irq();
               hereRECHECK:
               DebounceSwitch1();
               checkSW1 = checkSW1 + 1;
               if(SW1 == 1){                        //for all leds off state
                   RED_ON_S1 = 0;
                   RED_ON_S2 = 0;
                   GREEN_ON_S1 = 0;
                   GREEN_ON_S2 = 0;
                   BLUE_ON_S1 = 0;
                   BLUE_ON_S2 = 0;
                   P5OUT &= ~0x07;
                   IRQ = 0;
                   checkSW1 = 0;
                   counter = RED;
                   goto hereLEDSOFF;
               }
               if(checkSW1 <= 1000){                //makes sure switch 1 has been pressed after switch 2
                   goto hereRECHECK;
               }
               checkSW1 = 0;
               if(RED_ON_S2 == 1){                  //if red is on go to green
                   IRQ = 0;
                   counter = REDGREEN;
                   goto hereREDGREEN;
               }
               else if(GREEN_ON_S2 == 1){           //if green is on go to blue
                   IRQ = 0;
                   counter = REDBLUE;
                   goto hereREDBLUE;
               }
               else if(BLUE_ON_S2 == 1){            //if blue is on go to red
                   IRQ = 0;
                   counter = REDRED;
                   goto hereREDRED;
               }
               else{                                //default red to green
                   IRQ = 0;
                   counter = REDGREEN;
                   goto hereREDGREEN;
               }
           }
           //calling debounce for first switch
           for(i = 0; i <= 100; i++){               //ensures button has been released
               DebounceSwitch1();
               if(SW1 == 0){
                   Done = 1;
               }
           }
           DebounceSwitch1();                       //waits for new button press to switch states
           if(SW1 == 1 && Done == 1){
               counter = GREEN;
               Done = 0;
               goto hereGREEN;
           }
           goto hereRED;

           //RED RED
       case REDRED:
           hereREDRED:
           if(BLUE_ON_S1 == 0){                     //checks to see if blue is on from switch 1
               P5OUT &= ~0x04;                     //sets P5.2 to 0
               BLUE_ON_S2 = 0;
           }
           if(RED_ON_S2 == 0){                      //checks to see if red is on for switch 2
               DoneSW2 = 0;
               P5OUT |= 0x01;                      //sets P5.0 to 1
               RED_ON_S2 = 1;
           }
           //calling debounce for second switch
          for(i = 0; i <= 100; i++){                //ensures switch 2 has been released
              DebounceSwitch2();
              if(SW2 == 0){
                  DoneSW2 = 1;
                  counter = RED;
                  goto hereRED;
              }
          }
          goto hereREDRED;

          //RED GREEN
       case REDGREEN:
           hereREDGREEN:
           if(RED_ON_S1 == 0){                      //checks to see if red is on from switch 1
               P5OUT &= ~0x01;                     //sets P5.2 to 0
               RED_ON_S2 = 0;
           }
           if(GREEN_ON_S2 == 0){                    //checks to see if green is on from switch 2
               DoneSW2 = 0;
               P5OUT |= 0x02;                      //sets P5.0 to 1
               RED_ON_S2 = 0;
               GREEN_ON_S2 = 1;
           }
           //calling debounce for second switch
           for(i = 0; i <= 100; i++){               //ensures button has been released
               DebounceSwitch2();
               if(SW2 == 0){
                 DoneSW2 = 1;
                 counter = RED;
                 goto hereRED;
               }
           }
           goto hereREDGREEN;

           //RED BLUE
       case REDBLUE:
           hereREDBLUE:
           if(GREEN_ON_S1 == 0){                    //checks to see if green is on from switch 1
               P5OUT &= ~0x02;                     //sets P5.2 to 0
               GREEN_ON_S2 = 0;
           }
           if(BLUE_ON_S2 == 0){                     //checks to see if blue is on from switch 2
               DoneSW2 = 0;
               P5OUT |= 0x04;                      //sets P5.0 to 1
               BLUE_ON_S2 = 1;
           }
           //calling debounce for second switch
           for(i = 0; i <= 100; i++){               //ensures switch 2 has been released
               DebounceSwitch2();
               if(SW2 == 0){
                   DoneSW2 = 1;
                   counter = RED;
                   goto hereRED;
               }
           }
           goto hereREDBLUE;


       //---------------GREEN CASES--------------------//
       case GREEN:
           hereGREEN:
           if(RED_ON_S2 == 0){                      //checks to see if red is on from switch 2
               P5OUT &= ~0x01;                     //sets P5.2 to 0
               RED_ON_S1 = 0;                      //TURNS RED OFF
           }
           if(GREEN_ON_S1 == 0){                    //checks to see if green is on from switch 1
               Done = 0;
               P5OUT |= 0x02;                      //sets P5.0 to 1
               GREEN_ON_S1 = 1;                    //TURNS GREEN ON
           }
           for(i = 0; i <= 100; i++){               //ensures switch 2 has been released
               DebounceSwitch2();
               if(SW2 == 0){
                   DoneSW2 = 1;
               }
           }
           DebounceSwitch2();                       //checks for new button press for switch 2 to enable IRQ
           if(SW2 == 1 && DoneSW2 == 1 && IRQ == 0){
               DoneSW2 = 0;
               __enable_irq();
           }
           if(IRQ == 1){                            //IRQ states for second switch button colors
               __disable_irq();
               hereRECHECK2:
               DebounceSwitch1();
               checkSW1 = checkSW1 + 1;
               if(SW1 == 1){                        //for all leds off state
                   RED_ON_S1 = 0;
                   RED_ON_S2 = 0;
                   GREEN_ON_S1 = 0;
                   GREEN_ON_S2 = 0;
                   BLUE_ON_S1 = 0;
                   BLUE_ON_S2 = 0;
                   P5OUT &= ~0x07;
                   IRQ = 0;
                   checkSW1 = 0;
                   counter = RED;
                   goto hereLEDSOFF;
               }
               if(checkSW1 <= 1000){                //makes sure switch 1 has been pressed after switch 2
                   goto hereRECHECK2;
               }
               checkSW1 = 0;
               if(RED_ON_S2 == 1){                  //if red is on go to green
                   IRQ = 0;
                   counter = GREENGREEN;
                   goto hereGREENGREEN;
               }
               else if(GREEN_ON_S2 == 1){           //if green go blue
                   IRQ = 0;
                   counter = GREENBLUE;
                   goto hereGREENBLUE;
               }
               else if(BLUE_ON_S2 == 1){            //if blue go red
                   IRQ = 0;
                   counter = GREENRED;
                   goto hereGREENRED;
               }
               else{                                //default go blue
                   IRQ = 0;
                   counter = GREENBLUE;
                   goto hereGREENBLUE;
               }
           }
           //calling debounce for first switch
           for(i = 0; i <= 100; i++){               //ensures button has been released
               DebounceSwitch1();
               if(SW1 == 0){
                   Done = 1;
               }
           }
           DebounceSwitch1();                       //waits for button press to switch states
           if(SW1 == 1 && Done == 1){
               counter = BLUE;
               Done = 0;
               goto hereBLUE;
           }
           goto hereGREEN;


       case GREENRED:
           hereGREENRED:
           if(BLUE_ON_S1 == 0){                     //checks to see if blue is on from switch 1
               P5OUT &= ~0x04;                     //sets P5.2 to 0
               BLUE_ON_S2 = 0;
           }
           if(RED_ON_S2 == 0){                      //checks to see if red is on from switch 2
               DoneSW2 = 0;
               P5OUT |= 0x01;                      //sets P5.0 to 1
               RED_ON_S2 = 1;
           }
           //calling debounce for second switch
          for(i = 0; i <= 100; i++){                //ensures switch 2 has been released
              DebounceSwitch2();
              if(SW2 == 0){
                  DoneSW2 = 1;
                  counter = GREEN;
                  goto hereGREEN;
              }
          }
          goto hereGREENRED;


       case GREENGREEN:
           hereGREENGREEN:
           if(RED_ON_S1 == 0){                      //checks to see if red is on from switch 1
               P5OUT &= ~0x01;                     //sets P5.2 to 0
               RED_ON_S2 = 0;
           }
           if(GREEN_ON_S2 == 0){                    //checks to see if green is on from switch 2
               DoneSW2 = 0;
               P5OUT |= 0x02;                      //sets P5.0 to 1
               GREEN_ON_S2 = 1;
           }

           //calling debounce for second switch
           for(i = 0; i <= 100; i++){               //ensures button has been released
               DebounceSwitch2();
               if(SW2 == 0){
                 DoneSW2 = 1;
                 counter = GREEN;
                 goto hereGREEN;
               }
           }
           goto hereGREENGREEN;



       case GREENBLUE:
           hereGREENBLUE:
           if(GREEN_ON_S1 == 0){                    //checks to see if green is on from switch 1
               P5OUT &= ~0x02;                     //sets P5.2 to 0
               GREEN_ON_S2 = 0;
           }
           if(BLUE_ON_S2 == 0){                     //checks to see if blue is on from switch 2
               DoneSW2 = 0;
               P5OUT |= 0x04;                      //sets P5.0 to 1
               BLUE_ON_S2 = 1;
               GREEN_ON_S2 = 0;
           }
           //calling debounce for second switch
           for(i = 0; i <= 100; i++){               //ensures switch 2 has been released
               DebounceSwitch2();
               if(SW2 == 0){
                   DoneSW2 = 1;
                   counter = GREEN;
                   goto hereGREEN;
               }
           }
           goto hereGREENBLUE;



       //---------------BLUE CASES--------------------//
       case BLUE:
           hereBLUE:
           if(GREEN_ON_S2 == 0){                    //checks to see if green is on from switch 2
               P5OUT &= ~0x02;                     //sets P5.2 to 0
               GREEN_ON_S1 = 0;                      //TURNS GREEN OFF
           }
           if(BLUE_ON_S1 == 0){                     //checks to see if blue is on from switch 1
               Done = 0;
               P5OUT |= 0x04;                      //sets P5.0 to 1
               BLUE_ON_S1 = 1;                    //TURNS BLUE ON
           }
           for(i = 0; i <= 100; i++){               //ensuers button has been released for IRQ
               DebounceSwitch2();
               if(SW2 == 0){
                   DoneSW2 = 1;
               }
           }
           DebounceSwitch2();                       //checks for new button press for switch 2 to enable IRQ
           if(SW2 == 1 && DoneSW2 == 1 && IRQ == 0){
               DoneSW2 = 0;
               __enable_irq();
           }

           if(IRQ == 1){                            //IRQ states for second switch button colors
               __disable_irq();
               hereRECHECK3:
               DebounceSwitch1();
               checkSW1 = checkSW1 + 1;
               if(SW1 == 1){                        //for all leds off state
                   RED_ON_S1 = 0;
                   RED_ON_S2 = 0;
                   GREEN_ON_S1 = 0;
                   GREEN_ON_S2 = 0;
                   BLUE_ON_S1 = 0;
                   BLUE_ON_S2 = 0;
                   P5OUT &= ~0x07;
                   IRQ = 0;
                   checkSW1 = 0;
                   counter = RED;
                   goto hereLEDSOFF;
               }
               if(checkSW1 <= 1000){
                   goto hereRECHECK3;
               }
               checkSW1 = 0;
               if(RED_ON_S2 == 1){                  //if red go green
                   IRQ = 0;
                   counter = BLUEGREEN;
                   goto hereBLUEGREEN;
               }
               else if(GREEN_ON_S2 == 1){           //if green go blue
                   IRQ = 0;
                   counter = BLUEBLUE;
                   goto hereBLUEBLUE;
               }
               else if(BLUE_ON_S2 == 1){            //if blue go red
                   IRQ = 0;
                   counter = BLUERED;
                   goto hereBLUERED;
               }
               else{                                //default blue to red
                   IRQ = 0;
                   counter = BLUERED;
                   goto hereBLUERED;
               }
           }
           //calling debounce for first switch
           for(i = 0; i <= 100; i++){               //ensures button has been released
               DebounceSwitch1();
               if(SW1 == 0){
                   Done = 1;
               }
           }
           DebounceSwitch1();
           if(SW1 == 1 && Done == 1){               //waits for new button press to switch states
               counter = RED;
               Done = 0;
               goto hereRED;
           }
           goto hereBLUE;


       case BLUERED:
           hereBLUERED:
           if(BLUE_ON_S1 == 0){                     //checks to see if blue is on from switch 1
               P5OUT &= ~0x04;                     //sets P5.2 to 0
               BLUE_ON_S2 = 0;
           }
           if(RED_ON_S2 == 0){                      //checks to see if red is on from switch 2
               DoneSW2 = 0;
               P5OUT |= 0x01;                      //sets P5.0 to 1
               RED_ON_S2 = 1;
               BLUE_ON_S2 = 0;
           }

           //calling debounce for second switch
          for(i = 0; i <= 100; i++){                //ensures switch 2 has been released
              DebounceSwitch2();
              if(SW2 == 0){
                  DoneSW2 = 1;
                  counter = BLUE;
                  goto hereBLUE;
              }
          }
          goto hereBLUERED;


       case BLUEGREEN:
           hereBLUEGREEN:
           if(RED_ON_S1 == 0){                      //checks to see if red is on from switch 1
               P5OUT &= ~0x01;                     //sets P5.2 to 0
               RED_ON_S2 = 0;
           }
           if(GREEN_ON_S2 == 0){                    //checks to see if green is on from switch 2
               DoneSW2 = 0;
               P5OUT |= 0x02;                      //sets P5.0 to 1
               GREEN_ON_S2 = 1;
           }

           //calling debounce for second switch
           for(i = 0; i <= 100; i++){               //ensures button has been released
               DebounceSwitch2();
               if(SW2 == 0){
                 DoneSW2 = 1;
                 counter = BLUE;
                 goto hereBLUE;
               }
           }
           goto hereBLUEGREEN;


       case BLUEBLUE:
           hereBLUEBLUE:
           if(GREEN_ON_S1 == 0){                    //checks to see if green is on from switch 1
               P5OUT &= ~0x02;                     //sets P5.2 to 0
               GREEN_ON_S2 = 0;
           }
           if(BLUE_ON_S2 == 0){                     //checks to see if blue is on from switch 2
               DoneSW2 = 0;
               P5OUT |= 0x04;                      //sets P5.0 to 1
               BLUE_ON_S2 = 1;

           }

           //calling debounce for second switch
           for(i = 0; i <= 100; i++){               //ensures switch 2 has been pressed
               DebounceSwitch2();
               if(SW2 == 0){
                   DoneSW2 = 1;
                   counter = BLUE;
                   goto hereBLUE;
               }
           }
           goto hereBLUEBLUE;


       default:
           P5OUT &= ~0x07;                          //defualt case all leds off
           break;
       }
       }
    }
}

//initializes port 5 as outputs
void Port5_Initial(){
    P5SEL0 &= ~0x07;
    P5SEL1 &= ~0x07;
    P5DIR |= 0x07;
}
//initializes port 4 as inputs
void Port4_Initial(){
    P4SEL0 &= ~0x42;
    P4SEL1 &= ~0x42;
    P4DIR &= ~0x42;
    P4REN |= 0x42;
    P4OUT |= 0x42;
    P4IES |= 0x40;
    P4IE |= 0x40;
    P4IFG = 0;
}//initializes port 3 as inputs
void Port3_Initial(){
    P6SEL0 &= ~0x02;
    P6SEL1 &= ~0x02;
    P6DIR &= ~0x02;
    P6REN |= 0x02;
    P6OUT |= 0x02;
}
//IRQ HANDLER
void PORT4_IRQHandler(void){
    if(P4IFG & 0x40){                       //checks pin 4 if pressed
        IRQ = 1;
    }
    else if(RED_ON_S1 == 0 && RED_ON_S2 == 0 && GREEN_ON_S1 == 0 && GREEN_ON_S2 == 0 && BLUE_ON_S1 == 0 && BLUE_ON_S2 == 0){
        BLUE_ON_S2 = 1;                     //for first button press turning on blue
        P5OUT |= 0x04;                      //sets P5.0 to 1
    }
    P4IFG &= ~0x40;
}
uint8_t DebounceSwitch1()
{
    int VALUE = P4IN & 0x02;                        //checks P4.1
    //if a certain pin is high then set to high
    static uint16_t State = 0; // Current debounce status
    // read switch, upper 5 bits of State are don't cares
    State = (State<<1) | (P4IN & 0x02)>>1 | 0xf800;
    if(State == 0xfc00){
        if(VALUE == 0x00){                          //if button is pressed again after 5ms
            SW1 = 1;
            return 1;                               //set pin value to 1 because button is pressed
        }
        else{
            return 0;                               //else button is not pressed
        }
    }
    else if(State == 0xffff){                       //for button released
        SW1 = 0;
    }
    return 0;
}
uint8_t DebounceSwitch2()
{
    int VALUE = P6IN & 0x02;                        //checks P4.4
    //if a certain pin is high then set to high
    static uint16_t StateIRQ = 0; // Current debounce status
    // read switch, upper 5 bits of State are don't cares
    StateIRQ = (StateIRQ<<1) | (P6IN & 0x02)>>1 | 0xf800;
    if(StateIRQ == 0xfc00){
        if(VALUE == 0x00){                          //if button is pressed again after 5ms
            SW2 = 1;
            return 1;                               //set pin value to 1 because button is pressed
        }
        else{
            return 0;                               //else button is not pressed
        }
    }
    else if(StateIRQ == 0xffff){                    //for button released
        SW2 = 0;
    }
    return 0;
}
